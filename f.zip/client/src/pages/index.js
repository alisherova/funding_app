export {default as CardsPage} from './cardsPage/index.jsx'
export {default as CardsDetails} from './cardsDetails/index.jsx'